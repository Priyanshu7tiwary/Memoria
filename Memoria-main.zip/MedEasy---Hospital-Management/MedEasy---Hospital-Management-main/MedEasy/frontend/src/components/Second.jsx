import React from 'react'
import Third from './Third'

const Second = () => {
  return (
    <>
    <h1>Second Component is running</h1>
    <Third />
    </>
  )
}

export default Second