import React from 'react'
import Second from './Second'

const First = () => {
  return (
    <>
    <h1>First Component is running</h1>
    <Second />
    </>
  )
}

export default First