let Data=[
    {lname:'java',duration:'1 year',fees:250,trainer:'tanveer sir',img:'images/java.jpg'},
    {lname:'python',duration:'1 year',fees:250,trainer:'ranveer sir',img:'images/python.jpg'},
    {lname:'react',duration:'1 year',fees:250,trainer:'gourav sir',img:'images/react.jpg'}
];
export default Data;