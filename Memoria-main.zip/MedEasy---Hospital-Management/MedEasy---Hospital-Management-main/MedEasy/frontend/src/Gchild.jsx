import React from 'react'
const Gchild = () => {
  return (
    <>
    <h1>Gchild component is running</h1>
    </>
  )
}
export default Gchild