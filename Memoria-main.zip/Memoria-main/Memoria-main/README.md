## MemoryLane

- Developed a user-friendly website that invites users to share their cherished memories through personalized photo-cards and allow them to interact with each other

- Established a secure authentication system by integrating JWT (JSONWeb Tokens) and Google OAuth, ensuring user data protection and convenient login/authentication processes.
